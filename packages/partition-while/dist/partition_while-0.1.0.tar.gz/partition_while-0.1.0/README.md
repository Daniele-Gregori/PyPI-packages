# partition-while

The function partition-while splits a collection into sublists comprised of consecutive elements which satisfy a given condition.

For example:

```python
from partition_while.core import partition_while

print(partition_while([1,2,3,4,5,6,7,8,9,10], lambda x: sum(x) <= 10))
```